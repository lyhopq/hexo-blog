Code.require_file "server.exs", __DIR__

Alchemist.Server.start([System.argv])
